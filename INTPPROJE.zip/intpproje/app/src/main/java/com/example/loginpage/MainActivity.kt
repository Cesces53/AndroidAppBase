package com.example.loginpage

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import coil.compose.AsyncImage
import com.example.loginpage.ui.theme.LoginPageTheme
import com.google.firebase.auth.FirebaseAuth

// Renkleri tek bir yerden yönetmek için sabitler oluşturalım
val themeColor = Color(0xFF673AB7) // Canlı bir Mor tonu
val themeTextColor = Color.White

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            LoginPageTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    val navController = rememberNavController()
                    val isUserLoggedIn = FirebaseAuth.getInstance().currentUser != null
                    val startDestination = if (isUserLoggedIn) "home" else "login"

                    NavHost(navController = navController, startDestination = startDestination) {
                        composable("login") { LoginScreen(navController) }
                        composable("register") { RegisterScreen(navController) }
                        composable("home") { HomeScreen(navController) }
                    }
                }
            }
        }
    }
}

@Composable
fun HomeScreen(navController: NavHostController) {
    var selectedItemIndex by remember { mutableStateOf(0) }
    val tabs = listOf("Akış", "Ayarlar")

    Scaffold(
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { index, title ->
                    NavigationBarItem(
                        selected = selectedItemIndex == index,
                        onClick = { selectedItemIndex = index },
                        label = { Text(title) },
                        icon = {
                            when (index) {
                                0 -> Icon(Icons.Default.Home, contentDescription = title)
                                1 -> Icon(Icons.Default.Settings, contentDescription = title)
                            }
                        }
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier.padding(innerPadding)) {
            when (selectedItemIndex) {
                0 -> ReelsScreen()
                1 -> SettingsScreen(navController)
            }
        }
    }
}

@Composable
fun SettingsScreen(navController: NavHostController) {
    val auth = FirebaseAuth.getInstance()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Ayarlar", fontSize = 24.sp)
        Spacer(modifier = Modifier.height(16.dp))
        OutlinedButton( // Buton stilini Outlined olarak değiştirdik
            onClick = {
                auth.signOut()
                navController.navigate("login") {
                    popUpTo(navController.graph.findStartDestination().id) { inclusive = true }
                    launchSingleTop = true
                }
            },
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Default.Logout, contentDescription = "Çıkış Yap", tint = themeColor)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Çıkış Yap", color = themeColor)
        }
    }
}

@Composable
fun LoginScreen(navController: NavHostController) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    val auth = remember { FirebaseAuth.getInstance() }

    AuthScreenLayout(
        title = "Giriş Yap",
        email = email,
        onEmailChange = { email = it },
        password = password,
        onPasswordChange = { password = it },
        onPrimaryButtonClick = {
            if (email.isNotBlank() && password.isNotBlank()) {
                auth.signInWithEmailAndPassword(email.trim(), password.trim())
                    .addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            navController.navigate("home") {
                                popUpTo("login") { inclusive = true }
                            }
                        } else {
                            errorMessage = task.exception?.localizedMessage ?: "Giriş başarısız."
                        }
                    }
            } else {
                errorMessage = "E-posta ve şifre boş bırakılamaz."
            }
        },
        primaryButtonText = "Giriş Yap",
        primaryButtonIcon = Icons.Default.ArrowForward,
        onSecondaryButtonClick = { navController.navigate("register") },
        secondaryButtonText = "Hesabınız yok mu? Kayıt olun",
        errorMessage = errorMessage
    )
}

@Composable
fun RegisterScreen(navController: NavHostController) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    val auth = remember { FirebaseAuth.getInstance() }

    AuthScreenLayout(
        title = "Kayıt Ol",
        email = email,
        onEmailChange = { email = it },
        password = password,
        onPasswordChange = { password = it },
        onPrimaryButtonClick = {
            if (email.isNotBlank() && password.isNotBlank()) {
                auth.createUserWithEmailAndPassword(email.trim(), password.trim())
                    .addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            navController.navigate("home") {
                                popUpTo("register") { inclusive = true }
                            }
                        } else {
                            errorMessage = task.exception?.localizedMessage ?: "Kayıt başarısız."
                        }
                    }
            } else {
                errorMessage = "E-posta ve şifre boş bırakılamaz."
            }
        },
        primaryButtonText = "Kayıt Ol",
        primaryButtonIcon = Icons.Default.PersonAdd,
        onSecondaryButtonClick = { navController.popBackStack() },
        secondaryButtonText = "Zaten hesabınız var mı? Giriş yapın",
        errorMessage = errorMessage
    )
}

@Composable
fun AuthScreenLayout(
    title: String,
    email: String,
    onEmailChange: (String) -> Unit,
    password: String,
    onPasswordChange: (String) -> Unit,
    onPrimaryButtonClick: () -> Unit,
    primaryButtonText: String,
    primaryButtonIcon: ImageVector,
    onSecondaryButtonClick: () -> Unit,
    secondaryButtonText: String,
    errorMessage: String?
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF5F5F5))
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = title, fontSize = 30.sp, color = Color.Black)
        Spacer(modifier = Modifier.height(32.dp))

        OutlinedTextField(
            value = email,
            onValueChange = onEmailChange,
            label = { Text("E-posta") },
            modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
            singleLine = true,
            colors = TextFieldDefaults.colors( // Odaklanınca rengini değiştir
                focusedIndicatorColor = themeColor,
                focusedLabelColor = themeColor,
            )
        )

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = password,
            onValueChange = onPasswordChange,
            label = { Text("Şifre") },
            modifier = Modifier.fillMaxWidth(),
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            singleLine = true,
            colors = TextFieldDefaults.colors( // Odaklanınca rengini değiştir
                focusedIndicatorColor = themeColor,
                focusedLabelColor = themeColor
            )
        )

        errorMessage?.let {
            Spacer(modifier = Modifier.height(16.dp))
            Text(text = it, color = MaterialTheme.colorScheme.error)
        }

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = onPrimaryButtonClick,
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp),
            shape = RoundedCornerShape(12.dp), // Yuvarlak kenarlar
            colors = ButtonDefaults.buttonColors( // Yeni renkler
                containerColor = themeColor,
                contentColor = themeTextColor
            ),
            elevation = ButtonDefaults.buttonElevation(defaultElevation = 8.dp, pressedElevation = 4.dp) // Gölge
        ) {
            Icon(primaryButtonIcon, contentDescription = primaryButtonText)
            Spacer(modifier = Modifier.width(8.dp))
            Text(primaryButtonText, fontSize = 16.sp)
        }

        Spacer(modifier = Modifier.height(12.dp))

        TextButton(
            onClick = onSecondaryButtonClick,
            colors = ButtonDefaults.textButtonColors(contentColor = themeColor) // Rengi tema ile uyumlu yap
        ) {
            Text(secondaryButtonText)
        }
    }
}

@Composable
fun ReelsScreen() {
    val items = List(10) { "Gönderi ${it + 1}" }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(16.dp)
    ) {
        items(items) { item ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(450.dp),
                shape = RoundedCornerShape(16.dp), // Kartların kenarlarını da yuvarlatalım
                colors = CardDefaults.cardColors(containerColor = Color.DarkGray),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    AsyncImage(
                        model = "https://picsum.photos/seed/${item.hashCode()}/800/1200",
                        contentDescription = item,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )

                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        contentAlignment = Alignment.BottomStart
                    ) {
                        Text(
                            text = item,
                            color = Color.White,
                            fontSize = 20.sp,
                            style = MaterialTheme.typography.titleLarge
                        )
                    }
                }
            }
        }
    }
}